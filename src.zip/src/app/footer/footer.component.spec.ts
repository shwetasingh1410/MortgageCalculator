import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { FooterComponent } from './footer.component';

describe('FooterComponent', () => {
  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FooterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it(`should have as footer content 'Author: Shweta Singh'`, () => {
    const fixture = TestBed.createComponent(FooterComponent);
    const app = fixture.debugElement;
    const h1 = app.query(By.css('.container span'));
    expect(h1.nativeElement.innerText).toBe('Author: Shweta Singh');
  });
});
