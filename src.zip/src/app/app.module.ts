import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CoreComponent } from './core/core.component';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule }   from '@angular/forms';
import { PaymentCalculatorComponent } from './core/payment-calculator/payment-calculator.component';
import { sharedService } from './common/sharedService.service';
import { GridDataComponent } from './core/payment-calculator/grid-data/grid-data.component';
import { AgGridModule } from 'ag-grid-angular';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    CoreComponent,
    PaymentCalculatorComponent,
    GridDataComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    AgGridModule.withComponents([])
  ],
  providers: [
    sharedService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
