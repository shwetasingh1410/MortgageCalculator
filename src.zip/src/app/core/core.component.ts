import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'core',
  templateUrl: './core.component.html',
  styleUrls: ['./core.component.css']
})
export class CoreComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
