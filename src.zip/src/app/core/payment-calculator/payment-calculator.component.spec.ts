import { ComponentFixture, TestBed,inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { PaymentCalculatorComponent } from './payment-calculator.component';
import { shallow } from 'enzyme';

describe('PaymentCalculatorComponent', () => {
  let component: PaymentCalculatorComponent;
  let fixture: ComponentFixture<PaymentCalculatorComponent>;
 let fakeJokeService: any;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentCalculatorComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentCalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  
});
