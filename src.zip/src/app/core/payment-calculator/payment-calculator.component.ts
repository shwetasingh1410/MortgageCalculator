import { Component, OnInit } from '@angular/core';
import { sharedService } from '../../common/sharedService.service';

@Component({
  selector: 'payment-calculator',
  templateUrl: './payment-calculator.component.html',
  styleUrls: ['./payment-calculator.component.css']
})
export class PaymentCalculatorComponent implements OnInit {
  mortgageAmount: number = 100000;
  interestRate: number = 5;
  period: number = 25;
  paymentFrequency: number = 12;
  term : number = 5;
  prepaymentAmount: number = 0;
  prepaymentFrequency: number = 1;
  paymentStart: number = 1;
  filledValues = {};

  constructor(private sharedService: sharedService) { }
  
  ngOnInit(): void {
  }
  onSubmit(form) {
      this.mortgageAmount = form.mortgageAmount;
      this.interestRate =  form.interestRate; 
      this.period =  form.period;
      this.paymentFrequency = form.paymentFrequency;
      this.term =  form.term;
      this.prepaymentAmount = form.prepaymentAmount;
      this.prepaymentFrequency = form.prepaymentFrequency;
      this.paymentStart =  form.paymentStart;

      const mortgageAmountCalculated = this.mortgageAmount - this.prepaymentAmount; 
      this.sharedService.setFilledData(form);
      this.filledValues = form;
   
  }
}
