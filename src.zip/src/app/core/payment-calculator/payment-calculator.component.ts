import { Component, OnInit } from '@angular/core';
import { sharedService } from '../../common/sharedService.service';

@Component({
  selector: 'payment-calculator',
  templateUrl: './payment-calculator.component.html',
  styleUrls: ['./payment-calculator.component.css']
})
export class PaymentCalculatorComponent implements OnInit {
  mortgageAmount: number = 100000;
  interestRate: number = 5;
  period: number = 25;
  paymentFrequency: number = 12;
  term : number = 5;
  prepaymentAmount: number = 0;
  prepaymentFrequency: number = 1;
  paymentStart: number = 1;
  filledValues = {};
  mortgageAmountCalculated = 400000;
  constructor(private sharedService: sharedService) { }
  
  ngOnInit(): void {
    this.setInitialValues();
  }
  setInitialValues(){ 
    this.mortgageAmountCalculated = this.calculateMortgage(this.mortgageAmount, this.interestRate, this.paymentFrequency);
  }
  onSubmit(form) {
      this.sharedService.setFilledData(form);
      this.filledValues = form;
  }
  // Below function calculates the mortgage
  // Have used a simple (P*R*T) / 100 Formula for demo
  calculateMortgage(mortgageAmount, interestRate, paymentFrequency){
    return ((mortgageAmount * interestRate * paymentFrequency)/ 100);
  }
  sum(a,b){
    return a +b;
  }
}
