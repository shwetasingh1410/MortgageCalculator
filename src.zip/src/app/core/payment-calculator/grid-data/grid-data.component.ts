import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';

@Component({
  selector: 'app-grid-data',
  templateUrl: './grid-data.component.html',
  styleUrls: ['./grid-data.component.css']
})
export class GridDataComponent implements OnInit {
    @Input() mortgageValues;
    term: number = 60;
    period: string = "1 final payment of $495.10";

    constructor() {

    }

    ngOnInit() {
       this.term = 60;
       this.period = "1 final payment of $495.10";
    }
    ngOnChanges(){
   this.term = this.mortgageValues.paymentFrequency * this.mortgageValues.term;
   this.period = `1 final payment of ${this.mortgageValues.prepaymentAmount}`;
   }
}
