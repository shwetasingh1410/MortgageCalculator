import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { sharedService } from '../../../common/sharedService.service';
@Component({
  selector: 'app-grid-data',
  templateUrl: './grid-data.component.html',
  styleUrls: ['./grid-data.component.css']
})
export class GridDataComponent implements OnInit{
    @Input() mortgageValues;
    @Input() mortgageAmountCalculated;
    noOfPayments: number = 60;
    period: number = 300;
    prepaymentAmount: number = 0;
    mortageValue = {};

    constructor(private dataService: sharedService) {

    }

    ngOnInit() {
       this.noOfPayments = 60;
       this.period = 300;
       this.prepaymentAmount = 0.00;
    }
    ngOnChanges(){
        this.noOfPayments = this.mortgageValues.paymentFrequency * this.mortgageValues.term;
        this.period = this.mortgageValues.period * this.mortgageValues.paymentFrequency;
        this.prepaymentAmount = this.mortgageValues.prepaymentAmount;
        this.mortageValue = this.dataService.getFilledData();
   }
}
