import { ComponentFixture, TestBed,inject } from '@angular/core/testing';
import { GridDataComponent } from './grid-data.component';
import {sharedService} from '../../../common/sharedService.service';

describe('GridDataComponent', () => {
  let component: GridDataComponent;
  let fixture: ComponentFixture<GridDataComponent>;
  beforeEach(() => {
   TestBed.configureTestingModule({
      providers:[sharedService]
   })
  });
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GridDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GridDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('Should create Grid component', () => {
    expect(component).toBeTruthy();
  });
  
  it(`Should inject 'SharedService'`, inject([sharedService],(service: sharedService) =>{
     expect(service).toBeTruthy();
}))
});
