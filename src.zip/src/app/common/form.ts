export class Form {

  constructor(
    public mortgageAmount: number,
    public interestRate: number,
    public period: string,
    public frequency: string,
    public term: string
  ) {  }

}
