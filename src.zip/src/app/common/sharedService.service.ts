import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class sharedService {
    formData = {};

    constructor() { }

    getFilledData(){
       return this.formData;
    }

    setFilledData(formData){
        this.formData =  formData;
    }
}