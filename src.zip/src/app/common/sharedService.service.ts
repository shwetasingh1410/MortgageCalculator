import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class sharedService {
    formData = {};
    initialMortageValue = 0;

    constructor() { }

    getFilledData(){
       return this.formData;
    }

    setFilledData(formData){
        this.formData =  formData;
    }

    setInitialMortageValue(value){
        this.initialMortageValue = value;
    }
}